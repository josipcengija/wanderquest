import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF22B573);
  static const Color primaryDark = Color(0xFF006837);
  static const Color secondary = Color(0xFF00A99D);
  static const Color secondaryDark = Color(0xFF008A7D);
  static const Color offWhite = Color(0xFFD0D0D0);
  static const Color black = Color(0xFF000000);

  static const Color primaryWizard = Color(0xFF5197ED);
  static const Color secondaryWizard = Color(0xFFFFCF68);

  static const Color primaryWitch = Color(0xFF543172);
  static const Color secondaryWitch = Color(0xFFA2C5AE);
  
  static const Color primaryRanger = Color(0xFF056008);
  static const Color secondaryRanger = Color(0xFF5A3C18);

  static const Color primaryArtist = Color(0xFFFFCD18);
  static const Color secondaryArtist = Color(0xFFFF9FDA);

  static const Color primaryFighter = Color(0xFFE4872F);
  static const Color secondaryFighter = Color(0xFF45270A);

  static const Color primaryRogue = Color(0xFF158E1A);
  static const Color secondaryRogue = Color(0xFF5A3C18);
}

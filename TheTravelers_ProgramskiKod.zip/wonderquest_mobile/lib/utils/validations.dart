//create email validaiton function

bool validateEmailAddress(String input) {
  const emailRegex =
      r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';

  if (RegExp(emailRegex).hasMatch(input)) {
    return true;
  } else {
    return false;
  }
}
bool validatePassword(String password) {
  const lettersRegex = r'[a-Z]';
  const numbersRegex = r'[0-9]';
  if (password.length>=8 && RegExp(lettersRegex).hasMatch(password) && RegExp(numbersRegex).hasMatch(password)) {
    return true;
  } else {
    return false;
  }
}
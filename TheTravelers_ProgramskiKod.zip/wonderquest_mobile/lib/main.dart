import 'package:flutter/material.dart';
import 'package:wonderquest_mobile/pages/map.dart';
import 'package:wonderquest_mobile/pages/profile.dart';
import 'package:wonderquest_mobile/pages/quest.dart';
import 'package:wonderquest_mobile/pages/splash.dart';
import 'package:wonderquest_mobile/utils/colors.dart';
// import 'package:wonderquest_mobile/pages/register.dart';
// import 'package:wonderquest_mobile/pages/login.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(const WanderQuestApp());
}

class WanderQuestApp extends StatelessWidget {
  const WanderQuestApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WanderQuest',
      
      theme: ThemeData(
        appBarTheme: const AppBarTheme( backgroundColor: Colors.transparent),
        primaryColor: AppColors.primary,
        
      ),
      routes: {
        '/profile':(context) => const ProfileScreen(),
        '/map': (context) => const MapScreen(),
        '/quests': (context) => const QuestScreen()
      },
      home: const SplashPage(),

    );
  }
}

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    const ProfileScreen(),
    const MapScreen(),
    const QuestScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  //NAVIGACIJA
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("WanderQuest"),
      ),
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.map),
            label: 'Map'
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.question_mark),
            label: 'Quests',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[600],
        unselectedItemColor: Colors.grey, 
        showUnselectedLabels: true, 
        onTap: _onItemTapped,
        
      ),
    );
  }
}
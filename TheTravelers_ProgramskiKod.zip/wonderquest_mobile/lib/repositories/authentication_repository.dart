class AuthenticationRepository {
  bool _isUserSignedIn = false; // Simulate local authentication state

  bool checkIfUserSignedIn() {
    return _isUserSignedIn;
  }

  // Method to sign in user (simulate signing in locally)
  void signIn() {
    _isUserSignedIn = true;
  }

  // Method to sign out user (simulate signing out locally)
  void signOut() {
    _isUserSignedIn = false;
  }
}


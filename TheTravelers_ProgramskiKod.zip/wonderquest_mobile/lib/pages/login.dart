import 'package:flutter/material.dart';
import 'package:wonderquest_mobile/main.dart';
import 'package:wonderquest_mobile/utils/validations.dart';
import 'package:wonderquest_mobile/pages/register.dart';
import 'package:wonderquest_mobile/utils/colors.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginState();
}

TextEditingController _controllerEmail = TextEditingController();
TextEditingController _controller2 = TextEditingController();
bool isEmailValid = false;
bool isPasswordValid = true;
bool _emailError = false;
bool _passwordError = false;

class _LoginState extends State<LoginScreen> {
  @override

  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(child: content(),),
    );
  }

  Widget content() {
    return Column(
      children: [
        const SizedBox(
          height: 20,
          width: double.infinity,
          child: DecoratedBox (
            decoration: BoxDecoration(
            color: AppColors.primary,
          ),
        ),
        ),
        Container(
          width: double.infinity,
          height: 220,
          decoration: const BoxDecoration(
            color: AppColors.primary,
          ),
          child: Padding(
            padding: const EdgeInsets.all(30.0),
            child: Container(
              width:50,
              height:50,
              decoration:
                  const BoxDecoration(
                    shape: BoxShape.circle, 
                    color: Colors.white,
                    ),
              child: Image.asset(
                'images/Logo.png',
                fit:BoxFit.contain,
              ),
            ),
          ),
        ),

        const SizedBox(
          height: 50,
        ),

        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Welcome",
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
              ),
              const SizedBox(
                height: 10,
              ),
              const Text(
                "Sign in to continue.",
                style: TextStyle(fontSize: 20),
              ),

              const SizedBox(
                height: 20,
              ),

              inputForm("Email", _controllerEmail),

              const SizedBox(
                height: 20,
              ),

              inputForm("Password", _controller2),

              const SizedBox(
                height: 10,
              ),

              const Align(
                alignment: Alignment.centerRight,
                child: Text(
                  "Forgot your password?",
                  style: TextStyle(color: AppColors.primary),
                ),  
              ),

              const SizedBox(
                height: 10,
              ),


              Center( //login button
              child: GestureDetector(
                onTap: () {
                  setState(() {
                    _emailError = false;
                    _passwordError = false;

                    if (_checkLogin()) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (BuildContext context) => const MainPage()),
                      );
                    } else {
                      if (!isEmailValid) {
                        _emailError = true;
                      } else {
                        _passwordError = true;
                      }
                    }
                  });
                },

                child: Container(
                  width: 200,
                  height: 50,
                  decoration: BoxDecoration(
                    color: AppColors.primary,
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: const Center(
                    child: Text(
                      "Login",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              )
              ),


              const SizedBox(
                height: 50,
              ),
              Center( //leads to sign up
                  child:Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text("New User? "),
                      GestureDetector(
                        onTap: (){
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (BuildContext context) => const RegisterScreen()),
                          );
                        },                  
                      child: const Text(
                        "Sign Up",
                        style: TextStyle(color: AppColors.primary),
                      ),
                      )
                    ], 
                  
                  ),
              )
            ],
          ),
        )
      ],
    );
  }


Widget inputForm(String title, TextEditingController controller) {
  String? errorText;
  
  if (title == 'Email' && _emailError) {
    errorText = "Email doesn't exist";
  } else if (title == 'Password' && _passwordError) {
    errorText = "Incorrect password";
  } else {
    errorText = null;
  }

  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(title),
      const SizedBox(
        height: 10,
      ),
      Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
            border: title == "Email"
                ? Border.all(
            width: 0.5,
                    color: controller.text.isEmpty
                        ? Colors.grey
                        : isEmailValid
                            ? Colors.green
                            : Colors.red)
                : Border.all(width: 0.5, color: Colors.grey),
        ),
        child: Padding(
          padding: const EdgeInsets.only(left: 10.0),
          child: TextField(
            controller: controller,
            decoration: const InputDecoration(
              border: InputBorder.none,
            ),
            obscureText: title == "Password",
            onChanged: (value) {
              if (title == "Email") {
                if (value.isEmpty) {
                  setState(() {
                    isEmailValid = true;
                  });
                } else {
                  final isValid = validateEmailAddress(value);
                  if (isValid) {
                    setState(() {
                      isEmailValid = true;
                    });
                  } else {
                    setState(() {
                      isEmailValid = false;
                    });
                  }
                }
              }
              else{
                if(value=='password'){
                  isPasswordValid=true;
                }
                else{
                  isPasswordValid=false;
                }
              }
            },
          ),
        ),
      ),
      if (errorText != null) // Show error text if there is an error
        Padding(
          padding: const EdgeInsets.only(left: 10.0, top: 4.0),
          child: Text(
            errorText,
            style: const TextStyle(
              color: Colors.red,
              fontSize: 12,
            ),
          ),
        ),
    ],
  );
}
}

bool _checkLogin(){
  if(isEmailValid && isPasswordValid){
    _passwordError=false;
    _emailError=false;
    return true;
  }
  else if(isEmailValid){
    _passwordError=true;
    return false;
  }
  else{
    _emailError=true;
    return false;
  }
}

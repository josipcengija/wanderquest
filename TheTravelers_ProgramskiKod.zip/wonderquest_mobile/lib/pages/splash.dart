import 'package:flutter/material.dart';
import 'package:wonderquest_mobile/main.dart';
import 'package:wonderquest_mobile/pages/login.dart';
import 'package:wonderquest_mobile/repositories/authentication_repository.dart';

class SplashPage extends StatelessWidget {
  const SplashPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const _Splash();
  }
}

class _Splash extends StatefulWidget {
  const _Splash();

  @override
  State<_Splash> createState() => _SplashState();
}

class _SplashState extends State<_Splash> {
  bool _isUserSignedIn = false; // Simulate local authentication state

  @override
  void initState() {
    super.initState();
    // Simulate user authentication check after 1 second delay
    Future.delayed(const Duration(seconds: 5), _checkUserSignedIn);
  }

  void _checkUserSignedIn() {
    // Simulate user authentication status
    setState(() {
      _isUserSignedIn = AuthenticationRepository().checkIfUserSignedIn();
    });

    // Route user based on authentication status
    _routeUser();
  }

  void _routeUser() {
    if (_isUserSignedIn) {
      // If user is signed in, navigate to MainPage
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (BuildContext context) => const MainPage()),
      );
    } else {
      // If user is not signed in, navigate to LoginScreen
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (BuildContext context) => const LoginScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Image.asset(
          'images/SplashScreen.png',
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
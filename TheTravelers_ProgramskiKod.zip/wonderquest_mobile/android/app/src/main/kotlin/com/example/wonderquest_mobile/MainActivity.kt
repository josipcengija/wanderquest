package com.example.wonderquest_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

WonderQuest is an innovative application designed to revolutionize travel experiences
 by combining tourism with the adventurous world of RPG games. This project aims to provide 
 users with an interactive platform for exploring diverse locations in Croatia while 
 immersing themselves in captivating stories, legends, and local histories. Through WonderQuest,
 users can embark on a journey filled with discovery, adventure, and cultural enrichment.

# Getting Started
TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:
1.	Installation process
2.	Software dependencies: requires Android operating system.
3.	Latest releases
4.	API references

